import mysql.connector
import re
from bs4 import BeautifulSoup
import regex
import requests
import json
import mysql.connector
from mysql.connector import errorcode
Ydatabase=input('plz enter database name: ')
Yuser=input('plz enter user : ')
ypass=input('plz enter password : ')
cnx = mysql.connector.connect(user=Yuser, password=ypass,host='127.0.0.1',database=Ydatabase)
cursor=cnx.cursor()
name=input('enter car name :')
urll=['https://www.truecar.com/used-cars-for-sale/listings']
page1=[name,'/']
page1=zip(urll,page1)
count=1
countPages=1
listcar=[]
for key,value in page1:
	newurl=(key+'/'+value+'/')
	r=requests.get(newurl)
	soup=BeautifulSoup(r.text,'html.parser')
	val=soup.find_all('li', attrs={'class': 'margin-top-3 d-flex flex-grow col-md-6 col-xl-4'})
	for tag in val:
		valm=tag.find('div', attrs={'class': 'd-flex w-100 justify-content-between'})
		sm=valm.text.split()
		if len(sm)<=2:
			smm=sm
		else:
			smm="-unknown"
		listcarm=smm
		valp=tag.find('div', attrs={'data-test': 'vehicleCardPricingBlockPrice'})
		sp=valp.text.split()
		listcarp=list(sp)
		p=str(sp[0])
		m=str(smm[0])
		count+=1
		insert_stmt = ("INSERT INTO carsPM (name, p, m) " "VALUES (%s, %s, %s)")
		data = (name, p, m)
		cursor.execute(insert_stmt, data)
		cnx.commit()
		if count>20:
			break
	if count>20:
		break

while count<20:
	countPages+=1
	intstr=str(countPages)
	str1=('https://www.truecar.com/used-cars-for-sale/listings/'+name+'/?page=2')
	res=re.sub(r'(\d+)',intstr,str1)
	r2=requests.get(res)
	soup2=BeautifulSoup(r2.text,'html.parser')
	val2=soup2.find_all('li', attrs={'class': 'margin-top-3 d-flex flex-grow col-md-6 col-xl-4'})
	for tag2 in val2:
		valm2=tag2.find('div', attrs={'class': 'd-flex w-100 justify-content-between'})
		sm2=valm2.text.split()
		if len(sm2)<=2:
			smm2=sm2
		else:
			smm2="-unknown"
		listcarm2=smm2
		valp2=tag2.find('div', attrs={'data-test': 'vehicleCardPricingBlockPrice'})
		sp2=valp2.text.split()
		listcarp2=list(sp2)
		count+=1
		p=str(sp2[0])
		m=str(smm2[0])
		insert_stmt = ("INSERT INTO carsPM (name, p, m) " "VALUES (%s, %s, %s)")
		data = (name, p, m)
		cursor.execute(insert_stmt, data)
		cnx.commit()
		if count==20:
			break
	if count>19:
		break
cnx.close()



